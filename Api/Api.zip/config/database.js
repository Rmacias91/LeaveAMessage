//https://www.terlici.com/2015/08/13/mysql-node-express.html
//Guide to use multiple RDS instances to READ1 READ2 and WRITE1. And sync together.

var mysql = require('mysql')
  , async = require('async');



var statePool = null;


exports.connect = function(done) {
    statePool = mysql.createPool({
    host: 'rds-mysql-richie.cspovihzt7lp.us-east-2.rds.amazonaws.com',
    port: '3306',
    user: 'rmacias91',
    password: 'Beyblade06!',
    database: 'richiedb'
  })

  done()
}

//Grab database to Query info
exports.get = function() {
  return statePool;
}

//Functions below used for Testing..

//Insert Rows into Table(s)
// exports.fixtures = function(data) {
//   var pool = statePool;
//   if (!pool) return done(new Error('Missing database connection.'));

//   //two for Loops to grab keys and row values and inserts
//   var names = Object.keys(data.tables);
//   async.each(names, function(name, cb) {
//     async.each(data.tables[name], function(row, cb) {
//       var keys = Object.keys(row);
//       var values = keys.map(function(key) { return "'" + row[key] + "'" });

//       pool.query('INSERT INTO ' + name + ' (' + keys.join(',') + ') VALUES (' + values.join(',') + ')', cb)
//     }, cb)
//   }, done)
// }

// //Drop Table(s)
// exports.drop = function(tables, done) {
//   var pool = statePool;
//   if (!pool) return done(new Error('Missing database connection.'));

//   async.each(tables, function(name, cb) {
//     pool.query('DELETE * FROM ' + name, cb)
//   }, done)
// }